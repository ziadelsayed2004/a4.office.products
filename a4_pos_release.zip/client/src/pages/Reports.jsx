import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Button,
  MenuItem,
  Tab,
  Tabs,
  TextField,
} from '@mui/material';
import {
  AssessmentRounded,
  BadgeRounded,
  DownloadRounded,
  Inventory2Rounded,
  PointOfSaleRounded,
  RefreshRounded,
  SwapHorizRounded,
} from '@mui/icons-material';
import { api } from '../api/client.js';
import { PageHeader } from '../components/navigation/PageHeader.jsx';
import { MetricCard } from '../components/data/MetricCard.jsx';
import { DataTable } from '../components/data/DataTable.jsx';
import { StatusChip } from '../components/data/StatusChip.jsx';
import { FilterPanel } from '../components/forms/FilterPanel.jsx';
import { Field } from '../components/forms/Field.jsx';
import { LoadingState } from '../components/feedback/LoadingState.jsx';
import { AppSnackbar } from '../components/feedback/AppSnackbar.jsx';
import { dateTime, money, number, statusLabel } from '../utils/formatters.js';

const reportTabs = [
  { id: 'sales', label: 'المبيعات', icon: <PointOfSaleRounded /> },
  { id: 'preorders', label: 'الحجوزات', icon: <BadgeRounded /> },
  { id: 'inventory', label: 'المخزون', icon: <Inventory2Rounded /> },
  { id: 'shifts', label: 'الشيفتات', icon: <SwapHorizRounded /> },
];

const initialFilters = {
  startDate: '',
  endDate: '',
  cashierId: '',
  shiftId: '',
  categoryId: '',
  status: '',
  search: '',
  stockStatus: '',
};

function buildQuery(filters) {
  return new URLSearchParams(
    Object.entries(filters)
      .filter(([, value]) => value !== '' && value !== null && value !== undefined)
      .map(([key, value]) => [key, String(value)]),
  ).toString();
}

export default function Reports() {
  const [tab, setTab] = useState('sales');
  const [filters, setFilters] = useState(initialFilters);
  const [data, setData] = useState({ summary: {}, rows: [] });
  const [users, setUsers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState('');
  const [toast, setToast] = useState(null);

  const loadReferences = useCallback(async () => {
    try {
      const [usersResponse, categoriesResponse] = await Promise.all([
        api.get('/api/admin/users'),
        api.get('/api/categories?activeOnly=false'),
      ]);
      setUsers((usersResponse.data || []).filter((user) => user.role === 'Cashier'));
      setCategories(categoriesResponse.data || []);
    } catch {
      // Reference filters are optional; the report itself can still be used.
    }
  }, []);

  const load = useCallback(async (activeTab = tab, activeFilters = filters) => {
    setLoading(true);
    setError('');
    try {
      const query = buildQuery(activeFilters);
      const response = await api.get(`/api/admin/reports/${activeTab}${query ? `?${query}` : ''}`);
      const payload = response.data || {};
      const rowKey = activeTab === 'sales'
        ? 'orders'
        : activeTab === 'preorders'
          ? 'preorders'
          : activeTab === 'inventory'
            ? 'products'
            : 'shifts';
      setData({ summary: payload.summary || {}, rows: payload[rowKey] || [] });
    } catch (err) {
      setError(err.message);
      setData({ summary: {}, rows: [] });
    } finally {
      setLoading(false);
    }
  }, [filters, tab]);

  useEffect(() => {
    loadReferences();
    load('sales', initialFilters);
  }, [loadReferences]);

  const changeTab = (_, nextTab) => {
    setTab(nextTab);
    setFilters(initialFilters);
    load(nextTab, initialFilters);
  };

  const reset = () => {
    setFilters(initialFilters);
    load(tab, initialFilters);
  };

  const exportCsv = async () => {
    setExporting(true);
    try {
      const query = buildQuery(filters);
      await api.download(
        `/api/admin/reports/export?type=${tab}${query ? `&${query}` : ''}`,
        `تقرير_${tab}_${new Date().toISOString().slice(0, 10)}.csv`,
      );
      setToast({ message: 'تم تجهيز ملف التقرير للتنزيل.' });
    } catch (err) {
      setToast({ severity: 'error', message: err.message });
    } finally {
      setExporting(false);
    }
  };

  const columns = useMemo(() => {
    if (tab === 'sales') {
      return [
        { key: 'invoice_number', label: 'رقم الفاتورة', render: (row) => <span className="a4-ltr">{row.invoice_number}</span> },
        { key: 'created_at', label: 'التاريخ والوقت', render: (row) => dateTime(row.created_at) },
        { key: 'cashier_name', label: 'الكاشير' },
        { key: 'subtotal', label: 'قبل الخصم', render: (row) => money(row.subtotal) },
        { key: 'discount', label: 'الخصم', render: (row) => money(row.discount) },
        { key: 'total', label: 'الصافي', render: (row) => <strong>{money(row.total)}</strong> },
        {
          key: 'payments',
          label: 'طرق الدفع',
          render: (row) => row.payments?.length
            ? row.payments.map((payment) => `${payment.method}: ${money(payment.amount)}`).join(' + ')
            : '—',
        },
      ];
    }
    if (tab === 'preorders') {
      return [
        { key: 'preorder_number', label: 'رقم الحجز', render: (row) => <span className="a4-ltr">{row.preorder_number}</span> },
        { key: 'customer_name', label: 'العميل' },
        { key: 'customer_phone', label: 'الهاتف', render: (row) => <span className="a4-ltr">{row.customer_phone}</span> },
        { key: 'cashier_name', label: 'الكاشير' },
        { key: 'total_amount', label: 'الإجمالي', render: (row) => money(row.total_amount) },
        { key: 'deposit_paid', label: 'العربون', render: (row) => money(row.deposit_paid) },
        { key: 'remaining_amount', label: 'المتبقي', render: (row) => <strong>{money(row.remaining_amount)}</strong> },
        { key: 'status', label: 'الحالة', render: (row) => <StatusChip status={row.status} label={statusLabel(row.status)} /> },
        { key: 'created_at', label: 'تاريخ الحجز', render: (row) => dateTime(row.created_at) },
      ];
    }
    if (tab === 'inventory') {
      return [
        { key: 'name', label: 'المنتج' },
        { key: 'sku', label: 'رمز SKU', render: (row) => <span className="a4-ltr">{row.sku}</span> },
        { key: 'category_name', label: 'التصنيف' },
        { key: 'current_stock', label: 'المخزون الفعلي', render: (row) => <strong>{number(row.current_stock)}</strong> },
        { key: 'reserved_stock', label: 'الحجوزات المفتوحة', render: (row) => number(row.reserved_stock) },
        { key: 'low_stock_threshold', label: 'حد التنبيه', render: (row) => number(row.low_stock_threshold) },
        {
          key: 'stock_state',
          label: 'حالة المخزون',
          render: (row) => row.current_stock === 0
            ? <StatusChip status="inactive" label="نفد المخزون" />
            : row.current_stock <= row.low_stock_threshold
              ? <StatusChip status="warning" label="مخزون منخفض" />
              : <StatusChip status="active" label="متوفر" />,
        },
      ];
    }
    return [
      { key: 'id', label: 'رقم الشيفت', render: (row) => `#${row.id}` },
      { key: 'cashier_name', label: 'الكاشير' },
      { key: 'opened_at', label: 'وقت الفتح', render: (row) => dateTime(row.opened_at) },
      { key: 'closed_at', label: 'وقت الإغلاق', render: (row) => dateTime(row.closed_at) },
      { key: 'opening_cash', label: 'عهدة البداية', render: (row) => money(row.opening_cash) },
      { key: 'expected_closing_cash', label: 'المتوقع', render: (row) => money(row.expected_closing_cash) },
      { key: 'actual_closing_cash', label: 'الفعلي', render: (row) => money(row.actual_closing_cash) },
      { key: 'status', label: 'الحالة', render: (row) => <StatusChip status={row.status} /> },
    ];
  }, [tab]);

  const metrics = useMemo(() => {
    const summary = data.summary || {};
    if (tab === 'sales') {
      return [
        ['إجمالي قبل الخصم', money(summary.total_sales), 'قيمة السلع قبل الخصومات'],
        ['إجمالي الخصومات', money(summary.total_discount), 'الخصومات المسجلة'],
        ['صافي المبيعات', money(summary.total_net), 'القيمة المحصلة'],
        ['عدد الفواتير', number(summary.invoices_count), 'فاتورة مكتملة'],
      ];
    }
    if (tab === 'preorders') {
      return [
        ['عدد الحجوزات', number(summary.total_count), 'حسب الفلاتر الحالية'],
        ['إجمالي الحجوزات', money(summary.total_amount), 'قيمة الحجوزات كاملة'],
        ['العربون المحصل', money(summary.total_deposit_paid), 'تم تحصيله عند الحجز'],
        ['المبالغ المتبقية', money(summary.total_remaining_amount), 'تحصل عند الاستلام'],
      ];
    }
    if (tab === 'inventory') {
      return [
        ['إجمالي المنتجات', number(summary.total_products), 'منتج نشط'],
        ['مخزون منخفض', number(summary.low_stock_count), 'يحتاج إعادة تزويد'],
        ['نفد المخزون', number(summary.out_of_stock_count), 'رصيد صفر'],
      ];
    }
    return [
      ['إجمالي الشيفتات', number(summary.total_shifts), 'حسب الفلاتر الحالية'],
      ['شيفتات مفتوحة', number(summary.open_shifts), 'قيد التشغيل'],
      ['بانتظار المراجعة', number(summary.pending_review_shifts), 'تحتاج اعتماد الأدمن'],
      ['شيفتات مغلقة', number(summary.closed_shifts), 'تم اعتمادها'],
    ];
  }, [data.summary, tab]);

  return (
    <div className="a4-page">
      <PageHeader
        title="التقارير"
        description="اعرض المبيعات والحجوزات والمخزون والشيفتات، ثم صدّر النتائج إلى ملف CSV عربي متوافق مع Excel."
        actions={(
          <>
            <Button variant="outlined" startIcon={<RefreshRounded />} onClick={() => load()} disabled={loading}>تحديث</Button>
            <Button variant="contained" startIcon={<DownloadRounded />} onClick={exportCsv} disabled={exporting || loading}>
              {exporting ? 'جاري التصدير...' : 'تصدير التقرير'}
            </Button>
          </>
        )}
      />

      <section className="a4-page-section report-tabs-panel">
        <Tabs value={tab} onChange={changeTab} variant="scrollable" scrollButtons="auto" aria-label="أنواع التقارير">
          {reportTabs.map((item) => <Tab key={item.id} value={item.id} icon={item.icon} iconPosition="start" label={item.label} />)}
        </Tabs>
      </section>

      <FilterPanel resultCount={data.rows.length} onApply={() => load()} onReset={reset}>
        {tab !== 'inventory' && (
          <>
            <Field label="من تاريخ"><TextField type="date" value={filters.startDate} onChange={(event) => setFilters((state) => ({ ...state, startDate: event.target.value }))} /></Field>
            <Field label="إلى تاريخ"><TextField type="date" value={filters.endDate} onChange={(event) => setFilters((state) => ({ ...state, endDate: event.target.value }))} /></Field>
          </>
        )}
        {(tab === 'sales' || tab === 'preorders' || tab === 'shifts') && (
          <Field label="الكاشير">
            <TextField select value={filters.cashierId} onChange={(event) => setFilters((state) => ({ ...state, cashierId: event.target.value }))}>
              <MenuItem value="">كل الكاشير</MenuItem>
              {users.map((user) => <MenuItem key={user.id} value={user.id}>{user.name}</MenuItem>)}
            </TextField>
          </Field>
        )}
        {tab === 'sales' && (
          <>
            <Field label="رقم الشيفت"><TextField type="number" value={filters.shiftId} onChange={(event) => setFilters((state) => ({ ...state, shiftId: event.target.value }))} placeholder="اختياري" /></Field>
            <Field label="التصنيف">
              <TextField select value={filters.categoryId} onChange={(event) => setFilters((state) => ({ ...state, categoryId: event.target.value }))}>
                <MenuItem value="">كل التصنيفات</MenuItem>
                {categories.map((category) => <MenuItem key={category.id} value={category.id}>{category.name}</MenuItem>)}
              </TextField>
            </Field>
          </>
        )}
        {tab === 'preorders' && (
          <>
            <Field label="البحث"><TextField value={filters.search} onChange={(event) => setFilters((state) => ({ ...state, search: event.target.value }))} placeholder="رقم الحجز أو العميل أو الهاتف" /></Field>
            <Field label="حالة الحجز">
              <TextField select value={filters.status} onChange={(event) => setFilters((state) => ({ ...state, status: event.target.value }))}>
                <MenuItem value="">كل الحالات</MenuItem>
                <MenuItem value="DEPOSIT_PAID_WAITING_STOCK">بانتظار المخزون</MenuItem>
                <MenuItem value="READY_FOR_PICKUP">جاهز للاستلام</MenuItem>
                <MenuItem value="PICKED_UP">تم الاستلام</MenuItem>
                <MenuItem value="CANCELLED">ملغي</MenuItem>
              </TextField>
            </Field>
          </>
        )}
        {tab === 'inventory' && (
          <>
            <Field label="البحث"><TextField value={filters.search} onChange={(event) => setFilters((state) => ({ ...state, search: event.target.value }))} placeholder="اسم المنتج أو SKU أو الباركود" /></Field>
            <Field label="التصنيف">
              <TextField select value={filters.categoryId} onChange={(event) => setFilters((state) => ({ ...state, categoryId: event.target.value }))}>
                <MenuItem value="">كل التصنيفات</MenuItem>
                {categories.map((category) => <MenuItem key={category.id} value={category.id}>{category.name}</MenuItem>)}
              </TextField>
            </Field>
            <Field label="حالة المخزون">
              <TextField select value={filters.stockStatus} onChange={(event) => setFilters((state) => ({ ...state, stockStatus: event.target.value }))}>
                <MenuItem value="">الكل</MenuItem>
                <MenuItem value="LOW_STOCK">مخزون منخفض</MenuItem>
                <MenuItem value="OUT_OF_STOCK">نفد المخزون</MenuItem>
              </TextField>
            </Field>
          </>
        )}
        {tab === 'shifts' && (
          <Field label="حالة الشيفت">
            <TextField select value={filters.status} onChange={(event) => setFilters((state) => ({ ...state, status: event.target.value }))}>
              <MenuItem value="">كل الحالات</MenuItem>
              <MenuItem value="OPEN">مفتوح</MenuItem>
              <MenuItem value="PENDING_ADMIN_REVIEW">بانتظار المراجعة</MenuItem>
              <MenuItem value="CLOSED">مغلق</MenuItem>
            </TextField>
          </Field>
        )}
      </FilterPanel>

      {error && <Alert severity="error">{error}</Alert>}

      <div className="a4-grid a4-grid--metrics">
        {metrics.map(([label, value, hint]) => (
          <MetricCard key={label} icon={<AssessmentRounded />} label={label} value={value} hint={hint} />
        ))}
      </div>

      <section className="a4-page-section">
        {loading
          ? <LoadingState label="جاري تجهيز التقرير..." />
          : <DataTable columns={columns} rows={data.rows} mobilePrimary={(row) => row.invoice_number || row.preorder_number || row.name || `شيفت #${row.id}`} />}
      </section>
      <AppSnackbar state={toast} onClose={() => setToast(null)} />
    </div>
  );
}
